"""
main.py - starts the chat application
-------------------------------------
Open TWO terminals in this folder.

  Terminal 1 (start the server first):   python main.py server
  Terminal 2 (then start the client):    python main.py client

Optional settings:
  --host   address to use (default 127.0.0.1 = this computer)
           use  --host 0.0.0.0  on the server to accept other computers,
           and  --host <server-ip>  on the client to reach it
  --port   port number (default 5000)

Files:
  server.py  - socket code for the server
  client.py  - socket code for the client
  layout.py  - how messages are displayed on the screen
  main.py    - connects everything together (this file)
"""
import argparse
import sys

from client import ChatClient
from layout import ChatLayout
from server import ChatServer

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 5000
QUIT_COMMANDS = ("/quit", "/exit")


def parse_args():
    parser = argparse.ArgumentParser(description="Python socket chat")
    parser.add_argument("mode", nargs="?", choices=["server", "client"],
                        help="run as the server or as the client")
    parser.add_argument("--host", default=DEFAULT_HOST,
                        help=f"IP address (default {DEFAULT_HOST})")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT,
                        help=f"port number (default {DEFAULT_PORT})")
    return parser.parse_args()


def ask_mode():
    """Ask the user which role to play when no argument was given."""
    while True:
        answer = input("Run as server or client? ").strip().lower()
        if answer in ("server", "client"):
            return answer
        print("Please type 'server' or 'client'.")


def chat_loop(layout, backend):
    """Read what the user types and send it until they quit."""
    while True:
        try:
            text = layout.read_line().strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not text:
            continue
        if text.lower() in QUIT_COMMANDS:
            break
        if backend.send(text):
            layout.show_sent(text)


def main():
    args = parse_args()
    mode = args.mode or ask_mode()

    if mode == "server":
        layout = ChatLayout(peer_name="Client")
        layout.banner("PYTHON CHAT - SERVER",
                      f"Listening on {args.host}:{args.port}")
        backend = ChatServer(args.host, args.port,
                             on_message=layout.show_received,
                             on_status=layout.show_status)
        if not backend.start():
            sys.exit(1)
    else:
        layout = ChatLayout(peer_name="Server")
        layout.banner("PYTHON CHAT - CLIENT",
                      f"Server address {args.host}:{args.port}")
        backend = ChatClient(args.host, args.port,
                             on_message=layout.show_received,
                             on_status=layout.show_status)
        if not backend.connect():
            sys.exit(1)

    chat_loop(layout, backend)

    layout.show_status("Chat closed. Goodbye!")
    backend.stop()


if __name__ == "__main__":
    main()
