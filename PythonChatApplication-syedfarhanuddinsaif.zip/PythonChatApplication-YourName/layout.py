"""
layout.py - the "look" of the chat application (terminal layout)
----------------------------------------------------------------
All printing is done here, so server.py and client.py only deal with sockets.

Every line follows the same layout:

    [10:32:15] Client : Hello Server!      <- received message (green)
    [10:32:20] You    : Hi Client!         <- sent message     (cyan)
    [10:32:10] * Client connected ...      <- status message   (yellow)

Messages from the other side arrive on a background thread, so printing is
protected by a lock and the "You > " prompt is redrawn after each of them.
"""
import os
import sys
import threading
from datetime import datetime

try:
    import readline          # line editing for input() (not on Windows)
except ImportError:
    readline = None

# Colours only when printing to a real terminal (not when redirected to a file)
USE_COLOR = sys.stdout.isatty()
# Prompt and line-editing tricks only when a person is typing in a terminal
INTERACTIVE = sys.stdout.isatty() and sys.stdin.isatty()

if USE_COLOR and os.name == "nt":
    os.system("")            # switches on ANSI colours in Windows consoles

RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[32m"
CYAN = "\033[36m"
YELLOW = "\033[33m"
CLEAR_LINE = "\r\033[K"                  # go to column 0 and erase the line
ERASE_PREVIOUS_LINE = "\033[1A\r\033[K"  # move up one line and erase it


def paint(text, colour):
    return f"{colour}{text}{RESET}" if USE_COLOR else text


class ChatLayout:
    def __init__(self, peer_name):
        self.peer_name = peer_name
        self.name_width = max(len("You"), len(peer_name))
        self.prompt = "You > "
        self._lock = threading.RLock()
        self._reading = False        # True while waiting for the user to type

    # ------------------------------------------------------------------
    def banner(self, title, details):
        line = "=" * 60
        print(paint(line, BOLD))
        print(paint(f"  {title}", BOLD))
        print(f"  {details}")
        print(paint(line, BOLD))
        print("  Type a message and press Enter to send it.")
        print("  Type /quit to leave the chat.")
        print(paint(line, BOLD))
        sys.stdout.flush()

    @staticmethod
    def _time():
        return datetime.now().strftime("%H:%M:%S")

    def _line(self, name, text):
        return f"[{self._time()}] {name:<{self.name_width}} : {text}"

    # ------------------------------------------------------------------
    def _write(self, line):
        """Print one line safely, even while the user is typing."""
        with self._lock:
            redraw = INTERACTIVE and self._reading
            if redraw:
                sys.stdout.write(CLEAR_LINE)          # remove the prompt
            sys.stdout.write(line + "\n")
            if redraw:                                # put prompt + typed
                typed = readline.get_line_buffer() if readline else ""
                sys.stdout.write(self.prompt + typed)  # text back
            sys.stdout.flush()

    def show_received(self, text):
        self._write(paint(self._line(self.peer_name, text), GREEN))

    def show_sent(self, text):
        self._write(paint(self._line("You", text), CYAN))

    def show_status(self, text):
        self._write(paint(f"[{self._time()}] * {text}", YELLOW))

    # ------------------------------------------------------------------
    def read_line(self):
        """Wait for the user to type a line and return it."""
        with self._lock:
            self._reading = True
        try:
            text = input(self.prompt if INTERACTIVE else "")
        finally:
            with self._lock:
                self._reading = False
        if INTERACTIVE:
            # The terminal still shows "You > text". Erase it - show_sent()
            # prints the nicely formatted version instead.
            with self._lock:
                sys.stdout.write(ERASE_PREVIOUS_LINE)
                sys.stdout.flush()
        return text
