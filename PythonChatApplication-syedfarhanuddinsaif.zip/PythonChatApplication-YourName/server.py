"""
server.py - server side of the chat application
-----------------------------------------------
The server:
  1. creates a TCP socket, binds it to (host, port) and listens,
  2. accepts a client connection (in a background thread),
  3. receives the client's messages in a background thread and
  4. sends its own messages back with send().

It never prints anything itself. Instead it reports what happens through two
callback functions, so the display (layout.py) stays separate from the
networking code.
"""
import socket
import threading

BUFFER_SIZE = 1024
ENCODING = "utf-8"


class ChatServer:
    def __init__(self, host, port, on_message, on_status):
        self.host = host
        self.port = port
        self.on_message = on_message    # called with every received message
        self.on_status = on_status      # called with connection information
        self.server_socket = None
        self.client_socket = None       # the connected client (None if nobody)
        self.running = False

    # ------------------------------------------------------------------
    def start(self):
        """Bind and listen, then accept clients in a background thread.

        Returns True if the server is running, False if the port could not
        be opened (for example when it is already in use).
        """
        try:
            self.server_socket = socket.socket(socket.AF_INET,
                                               socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET,
                                          socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(1)
        except OSError as error:
            self.on_status(f"Could not start the server: {error}")
            return False

        self.running = True
        threading.Thread(target=self._serve, daemon=True).start()
        return True

    def _serve(self):
        while self.running:
            self.on_status(f"Waiting for a client on "
                           f"{self.host}:{self.port} ...")
            try:
                connection, address = self.server_socket.accept()
            except OSError:
                break                   # the socket was closed by stop()

            self.client_socket = connection
            self.on_status(f"Client connected from "
                           f"{address[0]}:{address[1]}")
            self._receive_loop(connection)

            self.client_socket = None
            if self.running:
                self.on_status("Client disconnected")

    def _receive_loop(self, connection):
        """Receive messages until the client disconnects.

        TCP is a byte stream, so every message is terminated with a newline
        and the data is split on it. This keeps messages separate even when
        several arrive at the same time.
        """
        buffer = b""
        while self.running:
            try:
                data = connection.recv(BUFFER_SIZE)
            except OSError:
                break
            if not data:                # empty bytes = client closed socket
                break
            buffer += data
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                if line:
                    self.on_message(line.decode(ENCODING, errors="replace"))
        connection.close()

    # ------------------------------------------------------------------
    def send(self, text):
        """Send a message to the client. Returns True if it was sent."""
        connection = self.client_socket
        if connection is None:
            self.on_status("No client is connected - message not sent")
            return False
        try:
            data = text.replace("\n", " ").encode(ENCODING) + b"\n"
            connection.sendall(data)
            return True
        except OSError as error:
            self.on_status(f"Message not sent: {error}")
            return False

    def stop(self):
        """Close every socket."""
        self.running = False
        for sock in (self.client_socket, self.server_socket):
            if sock is not None:
                try:
                    sock.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                sock.close()
