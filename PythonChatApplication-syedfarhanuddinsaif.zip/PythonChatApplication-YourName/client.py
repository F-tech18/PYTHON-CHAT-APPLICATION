"""
client.py - client side of the chat application
-----------------------------------------------
The client:
  1. creates a TCP socket and connects to the server's (host, port),
  2. receives the server's messages in a background thread and
  3. sends its own messages with send().

Like the server, it reports events through callbacks and never prints
anything itself (the display is handled by layout.py).
"""
import socket
import threading

BUFFER_SIZE = 1024
ENCODING = "utf-8"
CONNECT_TIMEOUT = 5     # seconds


class ChatClient:
    def __init__(self, host, port, on_message, on_status):
        self.host = host
        self.port = port
        self.on_message = on_message    # called with every received message
        self.on_status = on_status      # called with connection information
        self.sock = None
        self.running = False

    # ------------------------------------------------------------------
    def connect(self):
        """Connect to the server. Returns True on success, False on failure."""
        self.on_status(f"Connecting to {self.host}:{self.port} ...")
        try:
            self.sock = socket.create_connection((self.host, self.port),
                                                 timeout=CONNECT_TIMEOUT)
        except OSError as error:
            self.on_status(f"Could not connect to the server: {error}")
            self.on_status("Start the server first (python main.py server)")
            return False

        self.sock.settimeout(None)      # wait forever for incoming data
        self.running = True
        self.on_status("Connected to the server")
        threading.Thread(target=self._receive_loop, daemon=True).start()
        return True

    def _receive_loop(self):
        """Receive messages until the server closes the connection."""
        buffer = b""
        while self.running:
            try:
                data = self.sock.recv(BUFFER_SIZE)
            except OSError:
                break
            if not data:                # empty bytes = server closed socket
                break
            buffer += data
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                if line:
                    self.on_message(line.decode(ENCODING, errors="replace"))

        if self.running:                # the server went away on its own
            self.running = False
            self.on_status("The server closed the connection "
                           "(type /quit to exit)")

    # ------------------------------------------------------------------
    def send(self, text):
        """Send a message to the server. Returns True if it was sent."""
        if not self.running:
            self.on_status("Not connected - message not sent")
            return False
        try:
            data = text.replace("\n", " ").encode(ENCODING) + b"\n"
            self.sock.sendall(data)
            return True
        except OSError as error:
            self.on_status(f"Message not sent: {error}")
            return False

    def stop(self):
        """Close the connection."""
        self.running = False
        if self.sock is not None:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self.sock.close()
